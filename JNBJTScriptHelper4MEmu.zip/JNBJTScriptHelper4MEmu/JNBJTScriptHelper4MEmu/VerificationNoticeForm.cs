﻿using NAudio.Wave;
using Sunny.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JNBJTScriptHelper4MEmu
{
    public partial class VerificationNoticeForm : UIForm
    {
        float widthBit = 865f / 455f;
        public VerificationNoticeForm()
        {
            InitializeComponent();
            this.btn.FillHoverColor = Color.FromArgb(198, 80, 66);

            comboBox_Devices.ItemForm.SetRectColor(Color.FromArgb(198, 80, 66));
            comboBox_Devices.dropForm.SetRectColor(Color.FromArgb(198, 80, 66));
        }

        private void button_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        Dictionary<int, Bitmap> correctSamples = new Dictionary<int, Bitmap>()
        {
            { 1,JNBJTScriptHelper4MEmu.Properties.Resources._01},
            { 2,JNBJTScriptHelper4MEmu.Properties.Resources._02},
            { 3,JNBJTScriptHelper4MEmu.Properties.Resources._03},
            { 4,JNBJTScriptHelper4MEmu.Properties.Resources._04},
            { 5,JNBJTScriptHelper4MEmu.Properties.Resources._05},
            { 6,JNBJTScriptHelper4MEmu.Properties.Resources._06},
            { 7,JNBJTScriptHelper4MEmu.Properties.Resources._07},
            { 8,JNBJTScriptHelper4MEmu.Properties.Resources._08},
            { 9,JNBJTScriptHelper4MEmu.Properties.Resources._09},
            { 10,JNBJTScriptHelper4MEmu.Properties.Resources._10},
            { 11,JNBJTScriptHelper4MEmu.Properties.Resources._11},
            { 12,JNBJTScriptHelper4MEmu.Properties.Resources._12}
        };
        private void button_BrowseMEmuDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择模拟器的安装路径(该路径含有adb.exe文件)";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                textBox_MEmuDir.Text = foldPath;
            }
        }

        private void comboBox_Devices_DropDown(object sender, EventArgs e)
        {
            if (!CheckMEmuDir())
                return;

            String cmddevices = "\"" + textBox_MEmuDir.Text + "\\adb.exe" + "\" devices";
            CMDHelper.RunCmdCommand(cmddevices, out var result);

            Regex regex = new Regex(@"attached[\s\S]+\s{1}device");
            if (!regex.IsMatch(result))
            {

                UIMessageTip.ShowError(comboBox_Devices, "当下无可用设备!");
                return;
            }
            comboBox_Devices.Items.Clear();
            var match = regex.Match(result);
            foreach (Group group in match.Groups)
            {
                String data = group.Value.Replace("device", "").Replace("attached", "").Trim();
                String[] itemsList = data.Split('\r');
                foreach (var s in itemsList)
                {
                    String ss = Regex.Replace(s, "\\s*", "");
                    comboBox_Devices.Items.Add(ss);
                }

            }

            if (comboBox_Devices.Items.Count > 0)
                comboBox_Devices.SelectedIndex = 0;
        }

        public bool CheckMEmuDir()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(textBox_MEmuDir.Text);

            if (!directoryInfo.Exists)
            {
                UIMessageTip.ShowError(textBox_MEmuDir, "您选择的模拟器目录不存在!");
                return false;
            }

            if (!File.Exists(directoryInfo.FullName + "\\adb.exe"))
            {

                UIMessageTip.ShowError(textBox_MEmuDir, "请确认您选择的是模拟器的安装目录！该目录应含有adb.exe文件!!");
                return false;
            }

            return true;
        }

        private void button_Browse_TempCaptureDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "临时目录的安装路径";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                textBox_TempCaptureDir.Text = foldPath;
            }
        }
        System.Windows.Forms.Timer timerScreenShotAndAnalyse = new System.Windows.Forms.Timer();

        System.Windows.Forms.Timer countTimer = new System.Windows.Forms.Timer();

        int UnUsualCount = 1;
        bool alreadyStoped = false;
        private void button_OK_Click(object sender, EventArgs e)
        {
            try
            {
                if (button_OK.Text == "启动")
                {
                    if (!CheckMEmuDir())
                        return;

                    if (String.IsNullOrEmpty(comboBox_Devices.Text))
                    {
                        UIMessageTip.ShowError(comboBox_Devices, "您尚未选择模拟器设备");
                        return;
                    }

                    bool allUnchecked = !checkBox_NoticeTypeVoice.Checked && !checkBox_WindowsMess.Checked && !uiCheckBox_SkipSim.Checked;
                    if (allUnchecked)
                    {
                        UIMessageTip.ShowError(checkBox_NoticeTypeVoice, "系统消息、声音、自动验证三者必须勾选其中一项。");
                        return;
                    }

                    DirectoryInfo directoryInfo = new DirectoryInfo(textBox_TempCaptureDir.Text);

                    if (!directoryInfo.Exists)
                        directoryInfo.Create();

                    if (uiCheckBox_TempFiles.Checked)
                    {
                        String tempSlicePath = directoryInfo.FullName + "\\screen_slices";
                        directoryInfo = new DirectoryInfo(tempSlicePath);
                        if (!directoryInfo.Exists)
                            directoryInfo.Create();
                    }

                    if (File.Exists(textBox_TempCaptureDir.Text + "\\screen_temp.png"))
                    {
                        try
                        {
                            File.Delete(textBox_TempCaptureDir.Text + "\\screen_temp.png");
                        }
                        catch { }
                    }
                    AppendLogText("监控启动ing...");

                    UnUsualCount = 0;
                    isAnalysing = false;
                    alreadyStoped = false;

                    timerScreenShotAndAnalyse.Interval = 10;
                    timerScreenShotAndAnalyse.Tick += TimerScreenShotAndAnalyse_Tick;
                    timerScreenShotAndAnalyse.Start();

                    countTimer.Interval = 1000;
                    countTimer.Tick += CountTime_Tick;
                    countTimer.Start();

                    countTimer.Interval = 1000;
                    countTimer.Tick += CountTime_Tick;
                    countTimer.Start();

                    button_OK.Text = "停止";
                    AppendLogText("监控启动完成");
                    WriteIniData();
                    //uiTrackBar_TimerInterval.Enabled = false;
                }
                else
                {
                    //isAnalysing = false;
                    timerScreenShotAndAnalyse.Stop();
                    alreadyStoped = true;
                    //uiTrackBar_TimerInterval.Enabled = true;
                    countTimer.Stop();
                    countTimeSec = 0;
                    label_RuningTime.Text = "00:00:00";
                    label_CurrentSimBit.Text = "00.00%";
                    stopNoticeMusic();

                    if (frmShowWarning != null && !frmShowWarning.IsDisposed && frmShowWarning.Visible == true)
                        frmShowWarning.Hide();

                    timerScreenShotAndAnalyse.Tick -= TimerScreenShotAndAnalyse_Tick;
                    button_OK.Text = "启动";
                    AppendLogText("监控已停止");
                }
            }
            catch (Exception err)
            {
                //throw err;
                UIMessageTip.ShowError(button_OK, err.Message);
                //UIMessageDialog.ShowErrorDialog(this, "系统异常", err.Message);
            }
        }
        int countTimeSec = 0;
        private void CountTime_Tick(object sender, EventArgs e)
        {
            countTimeSec++;
            label_RuningTime.Text = GetTime(countTimeSec);
        }
        string GetTime(double time)
        {
            double h = Math.Floor(time / 3600f);
            double m = Math.Floor(time / 60f - h * 60f);
            double s = Math.Floor(time - m * 60f - h * 3600f);
            return h.ToString("00") + ":" + m.ToString("00") + ":" + s.ToString("00");
        }

        private WaveOutEvent outputDevice;
        private AudioFileReader audioFile;
        bool isAnalysing = false;
        private void TimerScreenShotAndAnalyse_Tick(object sender, EventArgs e)
        {
            if (timerScreenShotAndAnalyse.Interval == 10)
                timerScreenShotAndAnalyse.Interval = uiTrackBar_TimerInterval.Value * 1000;

            if (isAnalysing) return;


            isAnalysing = true;

            #region 处理分析
            Bitmap oldbitmapScreenShot = null;
            String screenshotPath = textBox_TempCaptureDir.Text + "\\screen_temp.png";
            if (File.Exists(screenshotPath))
                oldbitmapScreenShot = BitmapHelper.ReadImageFile(screenshotPath);

            AppendLogText("开始轮询截图");
            String adbPath = "\"" + textBox_MEmuDir.Text + "\\adb.exe" + "\"";
            String cmd1 = adbPath + " -s " + comboBox_Devices.Text + " shell /system/bin/screencap -p /sdcard/data/screen_temp.png ";
            CMDHelper.RunCmdCommand(cmd1, out var result1);

            if (result1.Contains("No such file or directory"))
            {
                String cmd1_5 = adbPath + " -s " + comboBox_Devices.Text + " shell mkdir /sdcard/data/";
                CMDHelper.RunCmdCommand(cmd1_5, out var result1_5);
                CMDHelper.RunCmdCommand(cmd1, out result1);
            }

            String cmd2 = adbPath + " -s " + comboBox_Devices.Text + " pull /sdcard/data/screen_temp.png " + textBox_TempCaptureDir.Text;
            CMDHelper.RunCmdCommand(cmd2, out var result2);

            using (var bitmapScreenShot = BitmapHelper.ReadImageFile(textBox_TempCaptureDir.Text + "\\screen_temp.png"))
            {
                var screenResult = BitmapHelper.CaculateSimilar(oldbitmapScreenShot, bitmapScreenShot);

                if (oldbitmapScreenShot != null)
                    oldbitmapScreenShot.Dispose();

                if (screenResult * 100 > uiTrackBar_UnusualSimBit.Value)
                {
                    UnUsualCount++;
                    AppendLogText("本次截图和上轮截图相似度为" + Math.Round(screenResult, 3) + "。异常警觉值加1。当下异常值为:" + UnUsualCount);
                }
                else
                {
                    UnUsualCount = 0;
                }


                if (CheckVerficationCodeShown(bitmapScreenShot))
                {
                    AppendLogText("警告：发现防机关术验证码!");

                    if (uiCheckBox_ASWarning.Checked)
                    {
                        if (checkBox_NoticeTypeVoice.Checked)
                            playNoticeMusic();

                        if (checkBox_WindowsMess.Checked)
                            ShowMessageTipForm();

                        if (uiCheckBox_SkipSim.Checked)
                            SkipVerficationCode();
                    }
                    else
                    {
                        if ((uiCheckBox_SkipSim.Checked && !SkipVerficationCode()) || !uiCheckBox_SkipSim.Checked)
                        {
                            if (checkBox_NoticeTypeVoice.Checked)
                                playNoticeMusic();

                            if (checkBox_WindowsMess.Checked)
                                ShowMessageTipForm();
                        }

                    }
                }
                else if (UnUsualCount >= uiTrackBar_MaxUnUsualCount.Value)
                {
                    AppendLogText("警告：异常值达到上限!请检查页面！");
                    if (uiCheckBox_ASWarning.Checked)
                    {
                        if (checkBox_NoticeTypeVoice.Checked)
                            playNoticeMusic();

                        if (checkBox_WindowsMess.Checked)
                            ShowMessageTipForm();

                        if (uiCheckBox_AutoHandleUnUsual.Checked)
                            HandleUnUsual();
                    }
                    else
                    {
                        if ((uiCheckBox_AutoHandleUnUsual.Checked && !HandleUnUsual()) || !uiCheckBox_AutoHandleUnUsual.Checked)
                        {
                            if (checkBox_NoticeTypeVoice.Checked)
                                playNoticeMusic();

                            if (checkBox_WindowsMess.Checked)
                                ShowMessageTipForm();
                        }

                    }
                }
                else
                {
                    stopNoticeMusic();
                    frmShowWarning.Hide();
                }

            }
            #endregion 

            isAnalysing = false;
        }

        private bool HandleUnUsual()
        {
            AppendLogText("开始处理异常情况...");
            using (var bitmapScreenShot = BitmapHelper.ReadImageFile(textBox_TempCaptureDir.Text + "\\screen_temp.png"))
            {
                var isPortrait = bitmapScreenShot.Height > bitmapScreenShot.Width;
                float regionXBit = 0, regionYBit = 0;
                float regionWidthBit = 0.1f, regionHeightBit = 0.1f;
                float handleBtnXBit = 0.5f, handleBtnYBit = 0.88f;

                if (!isPortrait)
                {
                    regionXBit = 12f / 1280;
                    regionYBit = 490f / 720;
                    regionWidthBit = 127f / 1280;
                    regionHeightBit = 212f / 720;
                    handleBtnXBit = 72f / 1280;
                    handleBtnYBit = 598f / 720;

                }
                else
                {
                    regionXBit = 536f / 720;
                    regionYBit = 1135f / 1280;
                    regionWidthBit = 159f / 720;
                    regionHeightBit = 123f / 1280;
                    handleBtnXBit = 307f / 720;
                    handleBtnYBit = 1195f / 1280;
                }
                int x = (int)Math.Round(bitmapScreenShot.Width * regionXBit);
                int w = (int)Math.Round(bitmapScreenShot.Width * regionWidthBit);

                int y = (int)Math.Round(bitmapScreenShot.Height * regionYBit);
                int h = (int)Math.Round(bitmapScreenShot.Height * regionHeightBit);

                int handleBtnX = (int)Math.Round(bitmapScreenShot.Width * handleBtnXBit);
                int handleBtnY = (int)Math.Round(bitmapScreenShot.Height * handleBtnYBit);

                var lostFocusSampleScreenBmp = (Bitmap)BitmapHelper.Crop(bitmapScreenShot, new Rectangle(x, y, w, h));
                Bitmap lostFocusSample = null;
                if (isPortrait)
                    lostFocusSample = Properties.Resources.lostFocusSample_portrait;
                else
                    lostFocusSample = Properties.Resources.lostFocusSample_landscape;

                var result = BitmapHelper.CaculateSimilar(lostFocusSampleScreenBmp, lostFocusSample);

                if (uiCheckBox_TempFiles.Checked)
                    lostFocusSampleScreenBmp.Save(textBox_TempCaptureDir.Text + "\\screen_lostfocus_crap.png");

                //int standard = uiTrackBar_UnusualSimBit.Value;
                //if (isPortrait)
                //    standard = standard - 30;
                int standard = 75;
                if (result * 100 > standard)
                {
                    AppendLogText($"确定异常情况为错失焦点！相似度为{Math.Round(result, 3)}");
                    String adbPath = "\"" + textBox_MEmuDir.Text + "\\adb.exe" + "\"";
                    String cmdClickSuccessBtn = adbPath + " -s " + comboBox_Devices.Text + $" shell input tap {handleBtnX} {handleBtnY}";
                    CMDHelper.RunCmdCommand(cmdClickSuccessBtn, out var result2);
                    AppendLogText("异常情况处理完成");
                    return true;
                }
                else
                {
                    AppendLogText($"确定异常情况为非错失焦点！相似度为{Math.Round(result, 3)}！需人工处理！");
                    return false;
                }
            }
        }

        private bool SkipVerficationCode()
        {

            AppendLogText("开始准备跳过验证码...");
            Dictionary<Point, Point> errorPoints = new Dictionary<Point, Point>();
            Point successBtnPoint = new Point(0, 0);
            var regionBmps = GetCurrentRegionSlices(ref successBtnPoint);
            foreach (Tuple<int, Bitmap, Point> region in regionBmps)
            {
                String textLog = $"正在检测切片{region.Item1}的准确性...";
                AppendLogText(textLog);

                Bitmap sample = correctSamples[region.Item1];
                var result = BitmapHelper.CaculateSimilar(region.Item2, sample);
                float standard = (float)((float)uiTrackBar_SkipSimBit.Value / 100);

                if (result < standard)
                {
                    textLog = $"切片{region.Item1}异常为错误切片！相似度仅为{Math.Round(result, 3)}";
                    AppendLogText(textLog);
                    var dicts = GetTheBestMatching(regionBmps, region, standard);
                    foreach (KeyValuePair<Point, Point> data in dicts)
                        errorPoints.AddOrUpdate(data.Key, data.Value);
                }
                else
                {
                    textLog = $"切片{region.Item1}通过检测,相似度为{Math.Round(result, 3) }";
                    AppendLogText(textLog);
                }
            }

            Dictionary<Point, Point> operatePoints = new Dictionary<Point, Point>();
            foreach (KeyValuePair<Point, Point> keyValuePair in errorPoints)
            {
                bool cns = operatePoints.Keys.Contains(keyValuePair.Key) || operatePoints.Values.Contains(keyValuePair.Key);
                if (!cns)
                    operatePoints[keyValuePair.Key] = keyValuePair.Value;
            }


            String adbPath = "\"" + textBox_MEmuDir.Text + "\\adb.exe" + "\"";
            String cmdFormat = adbPath + " -s " + comboBox_Devices.Text + " shell input swipe {0} {1} {2} {3} 300";
            int maxTryCount = uiTrackBar_SkipMaxCount.Value;
            int tryCount = 1;
            while (tryCount <= maxTryCount)
            {
                foreach (KeyValuePair<Point, Point> keyValuePair in operatePoints)
                {
                    if (alreadyStoped)
                        return false;

                    String cmd = String.Format(cmdFormat, keyValuePair.Key.X, keyValuePair.Key.Y, keyValuePair.Value.X, keyValuePair.Value.Y);
                    CMDHelper.RunCmdCommand(cmd, out var result);
                  //  AppendLogText("ADB移动指令结束。");
                    Random random = new Random((int)DateTime.Now.Ticks);
                    int sleepTime = random.Next(400, 800);
                    Thread.Sleep(sleepTime);
                   // AppendLogText("暂停"+sleepTime+"毫秒");
                    Application.DoEvents();

                    string textLog = $"当前尝试校正次数为{tryCount};正在将位置({keyValuePair.Key})的切片尝试移动到({keyValuePair.Value})";
                    AppendLogText(textLog);

                    if (!CheckVerficationCodeVisiableInTime())
                    {
                        //String cmdClickSuccessBtn = adbPath + " -s " + comboBox_Devices.Text + $" shell input tap {successBtnPoint.X} {successBtnPoint.Y}";
                        //CMDHelper.RunCmdCommand(cmdClickSuccessBtn, out var result2);
                        AppendLogText("防机关术已被成功骗过!");
                        return true;
                    }

                }
                Application.DoEvents();
                tryCount++;
            }

            return false;
        }

        private Dictionary<Point, Point> GetTheBestMatching(List<Tuple<int, Bitmap, Point>> curRegionSlices, Tuple<int, Bitmap, Point> currentRegionSlice, float standard)
        {
            Dictionary<Point, Point> errorPoints = new Dictionary<Point, Point>();
            Dictionary<int, float> similarResults = new Dictionary<int, float>();
            //AppendLogText("开始准备跳过验证码...");
            String logFormat = "切片{0}与标准样本{1}的相似度为{2}";
            foreach (KeyValuePair<int, Bitmap> paire in correctSamples)
            {
                if (paire.Key == currentRegionSlice.Item1)
                    continue;

                var resultCorrect = BitmapHelper.CaculateSimilar(currentRegionSlice.Item2, paire.Value);
                similarResults[paire.Key] = resultCorrect;

                AppendLogText(String.Format(logFormat, currentRegionSlice.Item1, paire.Key, Math.Round(resultCorrect, 3)));
            }

            KeyValuePair<int, float> bestSimilarItem = similarResults.OrderByDescending(x => x.Value).FirstOrDefault(x => x.Value > standard);// - 0.05f
            if (bestSimilarItem.Key > 0 && bestSimilarItem.Value > 0)
            {
                var bestItemKeyPaire = (KeyValuePair<int, float>)(bestSimilarItem);
                var bestCorrectRegionBmp = curRegionSlices.FirstOrDefault(x => x.Item1 == bestItemKeyPaire.Key);

                errorPoints[currentRegionSlice.Item3] = bestCorrectRegionBmp.Item3;
                String textLog = $"切片{currentRegionSlice.Item1}的最终匹配项为样本{bestItemKeyPaire.Key}";
                AppendLogText(textLog);

                //var regionBmp3 = curRegionSlices.FirstOrDefault(x => x.Item1 == 3);
                //var regionBmp4 = curRegionSlices.FirstOrDefault(x => x.Item1 == 4);

                //if (bestItemKeyPaire.Key == 3 && regionBmp4 != null)
                //{
                //    errorPoints[new Point(currentRegionSlice.Item3.X - 1, currentRegionSlice.Item3.Y - 1)] = regionBmp4.Item3;
                //    textLog = $"切片{currentRegionSlice.Item1}存在疑似匹配项为样本{regionBmp4.Item1}";
                //    AppendLogText(textLog);
                //}
                //else if (bestItemKeyPaire.Key == 4 && regionBmp3 != null)
                //{
                //    errorPoints[new Point(currentRegionSlice.Item3.X - 1, currentRegionSlice.Item3.Y - 1)] = regionBmp3.Item3;
                //    textLog = $"切片{currentRegionSlice.Item1}存在疑似匹配项为样本{regionBmp3.Item1}";
                //    AppendLogText(textLog);
                //}
            }
            return errorPoints;
        }

        private bool CheckVerficationCodeVisiableInTime()
        {
            String adbPath = "\"" + textBox_MEmuDir.Text + "\\adb.exe" + "\"";
            String cmd1 = adbPath + " -s " + comboBox_Devices.Text + " shell /system/bin/screencap -p /sdcard/data/screen_temp.png ";
           // AppendLogText("开始截图。");
            CMDHelper.RunCmdCommand(cmd1, out var result1);
           // AppendLogText("截图结束。");
            if (result1.Contains("No such file or directory"))
            {
                String cmd1_5 = adbPath + " -s " + comboBox_Devices.Text + " shell mkdir /sdcard/data/";
                CMDHelper.RunCmdCommand(cmd1_5, out var result1_5);
                CMDHelper.RunCmdCommand(cmd1, out result1);
            }

            String cmd2 = adbPath + " -s " + comboBox_Devices.Text + " pull /sdcard/data/screen_temp.png " + textBox_TempCaptureDir.Text;
            CMDHelper.RunCmdCommand(cmd2, out var result2);

            using (var bitmapScreenShot = BitmapHelper.ReadImageFile(textBox_TempCaptureDir.Text + "\\screen_temp.png"))
            {
                return CheckVerficationCodeShown(bitmapScreenShot);
            }
        }

        private List<Tuple<int, Bitmap, Point>> GetCurrentRegionSlices(ref Point successBtnPoint)
        {
            using (var bitmapScreenShot = BitmapHelper.ReadImageFile(textBox_TempCaptureDir.Text + "\\screen_temp.png"))
            {
                List<Tuple<int, Bitmap, Point>> tuples = new List<Tuple<int, Bitmap, Point>>();
                var isPortrait = bitmapScreenShot.Height > bitmapScreenShot.Width;

                float firstRegionLeftBit = 0, firstRegionTopBit = 0;
                float regionWidthBit = 0.1f, regionHeightBit = 0.1f, regionSepratorWidthBit = 0.000001f;
                float successBtnXBit = 0.5f, successBtnYBit = 0.88f;
                int bitmapWidth = bitmapScreenShot.Width;
                int bitmapHeight = bitmapScreenShot.Height;

                if (!isPortrait)
                {
                    firstRegionLeftBit = 0.2979166666666667f;
                    firstRegionTopBit = 0.4055555555555556f;
                    regionWidthBit = 0.0645833333333333f;
                    regionHeightBit = 0.1259259259259259f;
                    regionSepratorWidthBit = 5f / 1920;
                    successBtnXBit = 0.5f;
                    successBtnYBit = 0.88f;
                }
                else
                {
                    firstRegionLeftBit = 152f / 1080;
                    firstRegionTopBit = 858f / 1920;
                    regionWidthBit = 124f / 1080;
                    regionHeightBit = 136f / 1920;
                    regionSepratorWidthBit = 5f / 1080;
                    successBtnXBit = 0.5f;
                    successBtnYBit = 0.88f;
                }
                successBtnPoint = new Point((int)(successBtnXBit * bitmapWidth), (int)(successBtnYBit * bitmapHeight));
                int regionWidth = (int)Math.Round(regionWidthBit * bitmapWidth);
                int regionHeight = (int)Math.Round(regionHeightBit * bitmapHeight);
                int sepratorLineWidth = (int)Math.Round(regionSepratorWidthBit * bitmapWidth);
                int fisrtLeftX = (int)Math.Round(bitmapWidth * firstRegionLeftBit);
                int fisrtLeftY = (int)Math.Round(bitmapHeight * firstRegionTopBit);
                for (int j = 0; j < 2; j++)
                    for (int i = 0; i < 6; i++)
                    {
                        int x = fisrtLeftX + i * regionWidth + sepratorLineWidth * (i + 1) + (int)((i + 1) * 0.5);
                        int y = fisrtLeftY + j * regionHeight + sepratorLineWidth * (j + 1);
                        var bitmapScreenShotCodeRegion = (Bitmap)BitmapHelper.Crop(bitmapScreenShot, new Rectangle(x, y, regionWidth, regionHeight), false);
                        Point p = new Point(x + regionWidth / 2, y + regionHeight / 2);
                        tuples.Add(new Tuple<int, Bitmap, Point>(j * 6 + i + 1, bitmapScreenShotCodeRegion, p));
                        if (uiCheckBox_TempFiles.Checked)
                        {
                            String path = textBox_TempCaptureDir.Text + "\\screen_slices\\" + (j * 6 + i + 1).ToString("00") + ".png";
                            bitmapScreenShotCodeRegion.Save(path);
                        }
                    }
                return tuples;
            }
        }

        void playNoticeMusic()
        {
            if (outputDevice == null)
            {
                outputDevice = new WaveOutEvent();
                outputDevice.PlaybackStopped += OnPlaybackStopped;
            }
            if (audioFile == null)
            {
                audioFile = new AudioFileReader(Application.StartupPath + @"\\warning.mp3");
                outputDevice.Init(audioFile);
            }

            if (outputDevice.PlaybackState != PlaybackState.Playing)
                outputDevice.Play();
        }

        void stopNoticeMusic()
        {
            try
            {
                if (outputDevice?.PlaybackState == PlaybackState.Playing)
                    outputDevice?.Stop();

                outputDevice?.Dispose();
                audioFile?.Dispose();
                outputDevice = null;
                audioFile = null;
            }
            catch (Exception err)
            {
                AppendLogText(err.Message);
            }
        }
        private void OnPlaybackStopped(object sender, StoppedEventArgs args)
        {
            if (audioFile != null)
                audioFile.Position = 0;

            outputDevice?.Play();
        }

        private bool CheckVerficationCodeShown(Bitmap bitmapScreenShot)
        {
            try
            {
                //截图照片
                //var bitmapScreenShot = BitmapHelper.ReadImageFile(textBox_TempCaptureDir.Text + "\\screen_temp.png");
                var partbitMap = JNBJTScriptHelper4MEmu.Properties.Resources.sample;

                float xBit = 0.01f, yBit = 0.01f, widthBit = 0.01f, heightBit = 0.01f;

                var isPortrait = bitmapScreenShot.Height > bitmapScreenShot.Width;

                if (!isPortrait)//如果是横屏
                {
                    xBit = 0.258f;
                    widthBit = 0.493f;
                    yBit = 0.172f;
                    heightBit = 0.657f;
                }
                else
                {
                    xBit = 0.06805f;
                    widthBit = 0.866f;
                    yBit = 0.314f;
                    heightBit = 0.367f;
                }

                int newRegionX = (int)Math.Round(bitmapScreenShot.Width * xBit);
                int newRegionW = (int)Math.Round(bitmapScreenShot.Width * widthBit);

                int newRegionY = (int)Math.Round(bitmapScreenShot.Height * yBit);
                int newRegionH = (int)Math.Round(bitmapScreenShot.Height * heightBit);

                var bitmapScreenShotCodeRegion = (Bitmap)BitmapHelper.Crop(bitmapScreenShot, new Rectangle(newRegionX, newRegionY, newRegionW, newRegionH));
                var result = BitmapHelper.CaculateSimilar(bitmapScreenShotCodeRegion, partbitMap);

                if (uiCheckBox_TempFiles.Checked)
                    bitmapScreenShotCodeRegion.Save(textBox_TempCaptureDir.Text + "\\screentemp_crap.png");

                label_CurrentSimBit.Text = Math.Round(result, 4) * 100 + "%";
                var standard = (float)((float)label_similarBit.Value / 100);


                if (result > standard)
                {
                    AppendLogText("轮询截图相似度为" + Math.Round(result, 4) + $"。已超过阈值{standard}。即将警报！");
                    return true;
                }
                else
                {
                    AppendLogText("轮询截图相似度为" + Math.Round(result, 4) + $"。未超过阈值{standard}。无需警报！");
                    return false;
                }

            }
            catch
            {
                return false;
            }
        }

        MessageTipForm frmShowWarning = new MessageTipForm();
        public void ShowMessageTipForm()
        {
            if (frmShowWarning == null || frmShowWarning.IsDisposed)
                frmShowWarning = new MessageTipForm();

            Point p = new Point(Screen.PrimaryScreen.WorkingArea.Width - frmShowWarning.Width, Screen.PrimaryScreen.WorkingArea.Height);
            frmShowWarning.PointToScreen(p);
            frmShowWarning.Location = p;

            frmShowWarning.Show();
            for (int i = 0; i <= frmShowWarning.Height / 10 + 1; i++)
            {
                frmShowWarning.Location = new Point(p.X, p.Y - i * 10);
                Thread.Sleep(10);
                Application.DoEvents();
            }
        }

        private void VerificationNoticeForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            outputDevice?.Stop();
            outputDevice?.Dispose();
            audioFile?.Dispose();
            outputDevice = null;
            audioFile = null;
        }

        private void label_similarBit_ValueChanged(object sender, EventArgs e)
        {
            label_similarData.Text = label_similarBit.Value.ToString();
        }

        private void uiTrackBar_TimerInterval_ValueChanged(object sender, EventArgs e)
        {
            label_TimerInterval.Text = uiTrackBar_TimerInterval.Value.ToString();
            timerScreenShotAndAnalyse.Interval = uiTrackBar_TimerInterval.Value * 1000;
        }

        private void checkBox_NoticeType_Click(object sender, EventArgs e)
        {
            //UICheckBox checkBox = sender as UICheckBox;
            //bool allUnchecked = !checkBox_NoticeTypeVoice.Checked && !checkBox_WindowsMess.Checked;
            //if (allUnchecked)
            //{
            //    UIMessageTip.ShowError(checkBox, "声音和系统消息至少选一项！");
            //    checkBox.Checked = true;
            //}
        }
        String iniPath = Application.StartupPath + "\\data.ini";
        //private void textBox_MEmuDir_TextChanged(object sender, EventArgs e)
        //{
        //    //IniUtility.WriteIni("UserData", "AdbPath", textBox_MEmuDir.Text, iniPath);
        //}

        int wideWidth = 1;
        int narrowWidth = 1;
        private void VerificationNoticeForm_Load(object sender, EventArgs e)
        {

            ReadIniData();
            narrowWidth = Width;
            wideWidth = (int)(Width * widthBit);

        }

        public void WriteIniData()
        {
            IniUtility.WriteIni("UserData", "AdbPath", textBox_MEmuDir.Text, iniPath);
            IniUtility.WriteIni("UserData", "TempCaptureDir", textBox_TempCaptureDir.Text, iniPath);
            IniUtility.WriteIni("UserData", "NoticeVoice", checkBox_NoticeTypeVoice.Checked.ToString().ToUpper(), iniPath);
            IniUtility.WriteIni("UserData", "WindowsMess", checkBox_WindowsMess.Checked.ToString().ToUpper(), iniPath);
            IniUtility.WriteIni("UserData", "CaptureSimilarBit", label_similarBit.Value.ToString(), iniPath);
            IniUtility.WriteIni("UserData", "CaptureTimerInterval", uiTrackBar_TimerInterval.Value.ToString(), iniPath);

            IniUtility.WriteIni("UserData", "MaxUnusualCount", uiTrackBar_MaxUnUsualCount.Value.ToString(), iniPath);
            IniUtility.WriteIni("UserData", "AutoHandleUnusual", uiCheckBox_AutoHandleUnUsual.Checked.ToString().ToUpper(), iniPath);
            IniUtility.WriteIni("UserData", "UnusalSimBit", uiTrackBar_UnusualSimBit.Value.ToString(), iniPath);

            IniUtility.WriteIni("UserData", "SliceSimBit", uiTrackBar_SkipSimBit.Value.ToString(), iniPath);
            IniUtility.WriteIni("UserData", "SkipSim", uiCheckBox_SkipSim.Checked.ToString(), iniPath);
            IniUtility.WriteIni("UserData", "SkipMaxCount", uiTrackBar_SkipMaxCount.Value.ToString(), iniPath);
            IniUtility.WriteIni("UserData", "ASWarning", uiCheckBox_ASWarning.Checked.ToString().ToUpper(), iniPath);
            IniUtility.WriteIni("UserData", "TempFiles", uiCheckBox_TempFiles.Checked.ToString().ToUpper(), iniPath);
            AppendLogText("配置文件更新成功");
        }

        public void ReadIniData()
        {
            if (!File.Exists(iniPath))
                return;

            textBox_MEmuDir.Text = IniUtility.ReadIni("UserData", "AdbPath", textBox_MEmuDir.Text, iniPath);
            textBox_TempCaptureDir.Text = IniUtility.ReadIni("UserData", "TempCaptureDir", textBox_TempCaptureDir.Text, iniPath);
            checkBox_NoticeTypeVoice.Checked = IniUtility.ReadIni("UserData", "NoticeVoice", String.Empty, iniPath).ToUpper() == "TRUE";
            checkBox_WindowsMess.Checked = IniUtility.ReadIni("UserData", "WindowsMess", String.Empty, iniPath) == "TRUE";

            if (int.TryParse(IniUtility.ReadIni("UserData", "CaptureSimilarBit", "", iniPath), out var captureSimilarBit))
                label_similarBit.Value = captureSimilarBit;

            if (int.TryParse(IniUtility.ReadIni("UserData", "CaptureTimerInterval", "", iniPath), out var captureTimerInterval))
                uiTrackBar_TimerInterval.Value = captureTimerInterval;

            if (int.TryParse(IniUtility.ReadIni("UserData", "MaxUnusualCount", "", iniPath), out var maxUnusualCount))
                uiTrackBar_MaxUnUsualCount.Value = maxUnusualCount;

            uiCheckBox_AutoHandleUnUsual.Checked = IniUtility.ReadIni("UserData", "AutoHandleUnusual", String.Empty, iniPath).ToUpper() == "TRUE";

            if (int.TryParse(IniUtility.ReadIni("UserData", "UnusalSimBit", "", iniPath), out var unusalSimBit))
                uiTrackBar_UnusualSimBit.Value = unusalSimBit;

            if (int.TryParse(IniUtility.ReadIni("UserData", "SliceSimBit", "", iniPath), out var sliceSimBit))
                uiTrackBar_SkipSimBit.Value = sliceSimBit;

            uiCheckBox_SkipSim.Checked = IniUtility.ReadIni("UserData", "SkipSim", String.Empty, iniPath).ToUpper() == "TRUE";

            if (int.TryParse(IniUtility.ReadIni("UserData", "SkipMaxCount", "", iniPath), out var skipMaxCount))
                uiTrackBar_SkipMaxCount.Value = skipMaxCount;

            uiCheckBox_ASWarning.Checked = IniUtility.ReadIni("UserData", "ASWarning", String.Empty, iniPath).ToUpper() == "TRUE";

            uiCheckBox_TempFiles.Checked = IniUtility.ReadIni("UserData", "TempFiles", String.Empty, iniPath).ToUpper() == "TRUE";

            AppendLogText("配置文件读取成功");
        }


        private void uiTrackBar_SkipSimBit_ValueChanged(object sender, EventArgs e)
        {
            uiLabel_SkipSimBit.Text = uiTrackBar_SkipSimBit.Value.ToString();
        }

        private void uiTrackBar_SkipMaxCount_ValueChanged(object sender, EventArgs e)
        {
            uiLabel_SkipMaxCount.Text = uiTrackBar_SkipMaxCount.Value.ToString();
        }

        private void AppendLogText(String content)
        {
            alphaUITextBox_Log.AppendText("(" + DateTime.Now.ToString("yy-MM-dd HH:mm:ss fff") + "):" + "[" + content + "]\r\n");
        }

        private void uiTrackBar_UnUsualCount_ValueChanged(object sender, EventArgs e)
        {
            uiLabel_UnUsualVal.Text = uiTrackBar_MaxUnUsualCount.Value.ToString();
        }

        private void uiLinkLabel_ShowLog_Click(object sender, EventArgs e)
        {
            if (uiLinkLabel_ShowLog.Text == "显示日志")
            {
                Width = wideWidth;
                uiLinkLabel_ShowLog.Text = "隐藏日志";
            }
            else
            {
                Width = narrowWidth;
                uiLinkLabel_ShowLog.Text = "显示日志";
            }
        }

        private void uiTrackBar_UnsalSimBit_ValueChanged(object sender, EventArgs e)
        {
            uiLabel_UnsalSimBit.Text = uiTrackBar_UnusualSimBit.Value.ToString();
        }
    }
}
